# Film Emulation LUTs for Affinity Photo

This directory contains 46 color lookup table (LUT) files in the `.cube` format, generated from film type color profiles. These LUTs can be used in Affinity Photo and other photo editing software to apply film-like color grading to your sRGB Pentax RAW (DNG/PEF) files.

## About These LUTs

The LUTs were generated from film simulation parameters including:
- **White Balance/Temperature**: Adjusts color temperature (cooler/bluer or warmer/amber)
- **Saturation**: Controls color intensity
- **Contrast**: Adjusts tonal range
- **Brightness**: Controls overall lightness
- **Palette Adjustments**: Fine-tunes hue and saturation for 8 color ranges (red, orange, yellow, green, cyan, blue, purple, magenta)
- **Colorize**: Applies subtle tinting effects

## Film Profiles Included

### Agfa
- Agfa Futura 100, 200, 400
- Agfa RSX-II 200
- Agfa Optima 400
- Agfaphoto Vista Plus 200, 400

### Fuji
- Fuji Pro 160C, 160S, 400H, 800Z
- Fuji Superia X-TRA 100, 400, 800
- Fuji Superia 200, 1600
- Fujicolor C100, C200
- Fujichrome Astia 100F
- Fujichrome Provia 100F, 400F
- Fujichrome Sensia 100, 200
- Fujichrome Velvia 50, 100

### Kodak
- Kodachrome 64, 200
- Kodak Ektachrome 64 Pro, 400 Pro
- Kodak Elite Chrome 100, 200
- Kodak 100 Extra Colour
- Kodak Gold 100, 200
- Kodak Max 400
- Kodak Portra 160NC, 160VC, 400NC, 400VC, 800
- Kodak Prof. Ektar 100
- Kodak Ultracolor 100UC, 400UC

### ROLLEI
- ROLLEI Chrome CR 200
- ROLLEI Crossbird
- ROLLEI Nightbird

## How to Use in Affinity Photo

### Method 1: Using the LUT Adjustment Layer

1. Open your sRGB Pentax RAW file (DNG or PEF) in Affinity Photo
2. In the Layers panel, click the **Adjustment Layer** button (circle icon)
3. Select **LUT** from the menu
4. In the LUT adjustment panel that appears, click the **Load LUT** button
5. Navigate to the `.cube` file you want to use and select it
6. The LUT will be applied to your image
7. You can adjust the opacity of the LUT layer to control the strength of the effect

### Method 2: Using the LUT Filter

1. Open your image in Affinity Photo
2. Go to **Layer > New Adjustment Layer > LUT**
3. Click **Load LUT** and select your `.cube` file
4. Adjust the layer properties as needed

### Method 3: Batch Processing

You can also apply LUTs in batch:
1. Go to **File > New Batch Job**
2. Add your images
3. Add a **LUT Adjustment** step
4. Load your `.cube` file
5. Run the batch job

## Assumptions

These LUTs were generated with the following assumptions:
- Input files are **sRGB** color space
- Pentax RAW files (DNG/PEF) are developed using **Affinity's standard profile**
- The LUTs are designed to work with 8-bit or 16-bit images
- LUT size is **32x32x32** (standard for most applications)

## Technical Details

- **Format**: `.cube` (3D Lookup Table)
- **Size**: 32x32x32 (32,768 color transformations)
- **Domain**: 0.0 - 1.0 (full sRGB range)
- **Color Space**: sRGB input and output
- **Processing**: Linear color space for accurate color transformations

## Tips

1. **Start Subtle**: Many film LUTs can be strong. Try reducing the layer opacity to 50-70% for a more subtle effect.

2. **Combine with Other Adjustments**: Use LUTs as a starting point, then fine-tune with Levels, Curves, or HSL adjustments.

3. **Order Matters**: If using multiple adjustment layers, the order affects the final result. Typically, apply LUTs after basic exposure/white balance adjustments but before final color grading.

4. **Test on Different Images**: Film LUTs can look different on different photos. Test on a few images to see which profiles work best for your style.

5. **Create Presets**: Once you find a LUT you like, save the adjustment layer as a style preset for quick reuse.

## File Naming Convention

The LUT files are named using the original film type names with spaces replaced by underscores:
- `Fuji_Pro_160C.cube` = Fuji Pro 160C film emulation
- `Kodak_Portra_400VC.cube` = Kodak Portra 400VC film emulation
- etc.

## Compatibility

These `.cube` format LUTs are compatible with:
- Affinity Photo (Windows, macOS, iPad)
- Adobe Photoshop
- Adobe Lightroom (with LUT plugins)
- Capture One
- ON1 Photo RAW
- Luminar
- Many other photo and video editing applications

## Generation Information

These LUTs were generated from film type color profiles using a custom Python script that interprets the film simulation parameters and creates accurate 3D color transformations.

---

Generated for use with sRGB Pentax RAW files (DNG/PEF) in Affinity Photo.
